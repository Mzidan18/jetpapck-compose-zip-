package id.ac.unp.ft.informatika.jetpackcomposefix


import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import id.ac.unp.ft.informatika.jetpackcomposefix.HomeScreen
import id.ac.unp.ft.informatika.jetpackcomposefix.ProfileScreen
import id.ac.unp.ft.informatika.jetpackcomposefix.SettingsScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") { HomeScreen(navController) }
        composable("profile") { ProfileScreen(navController) }
        composable("settings") { SettingsScreen(navController) }
    }
}
